#include<iostream>
using namespace std;
int main()
{
	int i=0;
	int a=0;
	for(i=0;i<10;i++)
	{
		a=a+i;
	}
	a=2*a-1;
}
