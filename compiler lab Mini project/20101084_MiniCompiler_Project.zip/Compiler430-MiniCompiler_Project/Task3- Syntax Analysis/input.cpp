int main() {
	a = 77;
	b = 33;
	result1 = a+ b+ 11;
	while(count1)
	{
		count--;
	}	
	if(count=0)
	{
		count = count+2;
	}
	else{
		count=0;
	}
}
