int main(){
	
	int i, a, b;
	int nume=3.45;	
	for(i = 0;  i < 10; i++){
		a=i;
	}
	i=1;
}

