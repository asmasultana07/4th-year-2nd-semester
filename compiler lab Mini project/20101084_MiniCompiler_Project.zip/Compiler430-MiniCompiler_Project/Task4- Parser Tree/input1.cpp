int main(){
	
	int a, b;
	a = 77;
	b = 33;
	int result1 = a+ b+ 11;
	if(a>=b)
	{
		result1= 0;
		a= a+b; 
	} 
}S
